# Salon Remote — télécommande universelle IR (Poco X6 Pro 5G)

Application Android native (Kotlin, Jetpack Compose, Material 3, thème AMOLED) qui pilote en infrarouge :

1. **TV LED Metz série MUC61** (IR + option Wi-Fi Android TV Remote v2)
2. **Barre de son Creative Stage V2** (IR)
3. **Vidéoprojecteur Yaber Pro V7** (IR)

Elle utilise l'émetteur IR du Xiaomi Poco X6 Pro 5G via `ConsumerIrManager` (minSdk 26, targetSdk 35).

> ⚠️ **Les codes IR fournis sont des valeurs de départ**, pas des codes vérifiés sur vos appareils. Utilisez l'écran
> *Réglages / Calibrage* (voir plus bas) pour trouver et enregistrer les bons codes de chaque touche.

## 1. Obtenir l'APK (sans Android Studio)

1. Poussez le dépôt sur GitHub (voir la section « Commandes Git »).
2. Onglet **Actions** → workflow **Build APK** (il se lance à chaque push sur `main`, ou via **Run workflow**).
3. Ouvrez l'exécution terminée → section **Artifacts** → téléchargez **app-debug-apk** (un `.zip` contenant `app-debug.apk`).

Le fichier `gradle-wrapper.jar` n'est pas versionné : le workflow génère le wrapper automatiquement (Gradle 8.9).

## 2. Installer l'APK sur le Poco X6 Pro 5G

1. Téléchargez le `.zip` depuis GitHub sur le téléphone, puis extrayez `app-debug.apk` (gestionnaire de fichiers Xiaomi).
2. Ouvrez l'APK. HyperOS/MIUI demande d'autoriser l'installation depuis cette source :
   **Paramètres → Applications → Autorisations → Installation d'applications inconnues** (ou suivez la fenêtre proposée).
3. Si une vérification de sécurité apparaît, choisissez « Installer quand même ».
4. Lancez **Salon Remote**. Pointez le **haut du téléphone** (émetteur IR sur la tranche supérieure) vers l'appareil.

## 3. Calibrer les codes IR

Icône ⚙ en haut à droite → **Réglages / Calibrage**.

### A. Tester / modifier une touche
- Choisissez l'appareil, puis la touche. Le code actuel s'affiche.
- Formats acceptés :
  - `NEC:0x00:0x08` — adresse 8 bits + commande 8 bits (compléments ajoutés automatiquement)
  - `NECX:0x1234:0x08` — NEC étendu (adresse 16 bits)
  - `NEC32:0x00FF08F7` — 32 bits bruts (octets envoyés de gauche à droite, LSB en premier)
  - `RC5:0x05:0x0C` — RC5 (36 kHz)
  - `PRONTO:0000 006D 0022 0002 …` — code Pronto Hex complet (ou collez-le tel quel)
- **Tester** envoie la trame, **Enregistrer** la mémorise pour cette touche, **Défaut** restaure la valeur d'origine.

### B. Balayage de commandes (si vous ne connaissez pas le code)
1. Choisissez le format (NEC / NEC étendu / RC5) et l'adresse (hex).
2. Appuyez sur **+ cmd** / **− cmd** : chaque pression envoie la commande suivante/précédente.
3. Dès que l'appareil réagit (ex. le volume change), appuyez sur **Utiliser ce code pour « touche »** puis **Enregistrer**.
4. Si rien ne réagit, essayez une autre adresse (`00`, `80`, `40`, `20`…), le format *NEC étendu*, ou importez un code Pronto
   (base de données Pronto/LIRC/IRDB, ou fichier exporté d'une autre application).

Astuce : calibrez d'abord **Power**, **Volume** et **OK**, puis le reste.

### C. TV Metz en Wi-Fi (option)
1. Dans le calibrage, saisissez l'IP de la TV (Réglages réseau de la TV, de préférence réservez-la dans votre box).
2. **Appairer** : un code à 6 caractères s'affiche sur la TV → saisissez-le → **Valider**.
3. Sur l'onglet TV, choisissez le mode **Wi-Fi**. Le mode IR reste disponible à tout moment.
La partie Wi-Fi implémente le protocole Android TV Remote v2 sans bibliothèque tierce ; elle est à tester sur votre TV.

## 4. Architecture

```
app/src/main/java/com/salonremote/
├── MainActivity.kt, RemoteViewModel.kt
├── ir/
│   ├── IrTransmitterManager.kt   émission + répétition (appui maintenu)
│   ├── IrEncoder.kt              NEC / NEC étendu / RC5 / Pronto → tableaux d'impulsions (µs)
│   ├── IrCode.kt, Keys.kt, Device.kt, IrCodeRepository.kt (codes + surcharges utilisateur)
│   └── codes/ MetzCodes.kt, CreativeStageCodes.kt, YaberCodes.kt
├── wifi/AndroidTvRemoteClient.kt  Android TV Remote v2 (TLS + protobuf)
└── ui/  RemoteApp, TvMetzScreen, SoundbarScreen, ProjectorScreen, CalibrationScreen, Components, theme
```

Pour modifier les codes par défaut dans le code : éditez les trois fichiers de `ir/codes/`.

## 5. Commandes Git

```bash
cd SalonRemote
git init -b main
git add .
git commit -m "Salon Remote : télécommande universelle IR"
git remote add origin https://github.com/<votre-utilisateur>/SalonRemote.git
git push -u origin main
```

## Compilation locale (optionnel)

JDK 17 + Android SDK 35, puis `gradle wrapper --gradle-version 8.9` et `./gradlew assembleDebug`.
