package com.salonremote.ir

enum class Device(val title: String) {
    TV("TV Metz"),
    SOUNDBAR("Barre Stage V2"),
    PROJECTOR("Projecteur Yaber")
}
