package com.salonremote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salonremote.RemoteViewModel
import com.salonremote.ir.Device
import com.salonremote.ir.Keys

private val D = Device.SOUNDBAR

@Composable
fun SoundbarScreen(vm: RemoteViewModel) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key(vm, D, Keys.POWER, Modifier.weight(1f).height(60.dp), container = Color(0xFFD32F2F)) {
                KeyIcon(Icons.Filled.PowerSettingsNew, "Power")
            }
            Key(vm, D, Keys.MUTE, Modifier.weight(1f).height(60.dp)) { KeyIcon(Icons.Filled.VolumeOff, "Mute") }
        }
        Text("Entrées", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        SourceRow(
            vm, D,
            listOf(
                Keys.IN_ARC to "TV ARC", Keys.IN_BT to "Bluetooth", Keys.IN_OPT to "Optique",
                Keys.IN_USB to "USB", Keys.IN_AUX to "AUX"
            )
        )

        Text("Audio", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Key(vm, D, Keys.VOL_DOWN, Modifier.weight(1f).height(84.dp)) { KeyIcon(Icons.Filled.Remove, "Volume -", 34) }
            Key(vm, D, Keys.VOL_UP, Modifier.weight(1f).height(84.dp)) { KeyIcon(Icons.Filled.Add, "Volume +", 34) }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Key(vm, D, Keys.PREV, Modifier.weight(1f).height(64.dp)) { KeyIcon(Icons.Filled.SkipPrevious, "Précédent", 30) }
            Key(vm, D, Keys.PLAY_PAUSE, Modifier.weight(1.3f).height(64.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    KeyIcon(Icons.Filled.PlayArrow, "Lecture", 28)
                    KeyIcon(Icons.Filled.Pause, "Pause", 28)
                }
            }
            Key(vm, D, Keys.NEXT, Modifier.weight(1f).height(64.dp)) { KeyIcon(Icons.Filled.SkipNext, "Suivant", 30) }
        }

        Text("Réglages acoustiques", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Stepper(vm, D, Keys.BASS_DOWN, Keys.BASS_UP, "Basses")
        Stepper(vm, D, Keys.TREBLE_DOWN, Keys.TREBLE_UP, "Aigus")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key(vm, D, Keys.SURROUND, Modifier.weight(1f).height(56.dp)) { KeyLabel("Surround") }
            Key(vm, D, Keys.DIALOG, Modifier.weight(1f).height(56.dp)) { KeyLabel("Dialog (Voix)") }
        }
    }
}
