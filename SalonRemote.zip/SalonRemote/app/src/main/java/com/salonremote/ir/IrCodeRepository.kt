package com.salonremote.ir

import android.content.Context
import com.salonremote.ir.codes.CreativeStageCodes
import com.salonremote.ir.codes.MetzCodes
import com.salonremote.ir.codes.YaberCodes

/** Codes par défaut + surcharges utilisateur (SharedPreferences) issues du calibrage. */
class IrCodeRepository(context: Context) {
    private val prefs = context.getSharedPreferences("ir_codes", Context.MODE_PRIVATE)

    private fun defaults(d: Device): Map<String, IrCode> = when (d) {
        Device.TV -> MetzCodes.codes
        Device.SOUNDBAR -> CreativeStageCodes.codes
        Device.PROJECTOR -> YaberCodes.codes
    }

    fun keys(d: Device): List<String> = defaults(d).keys.toList()

    fun getDefault(d: Device, key: String): IrCode? = defaults(d)[key]

    fun isCustom(d: Device, key: String): Boolean = prefs.contains(prefKey(d, key))

    fun get(d: Device, key: String): IrCode? {
        val custom = prefs.getString(prefKey(d, key), null)?.let { IrCode.parse(it) }
        return custom ?: defaults(d)[key]
    }

    fun set(d: Device, key: String, code: IrCode) {
        prefs.edit().putString(prefKey(d, key), code.toText()).apply()
    }

    fun reset(d: Device, key: String) {
        prefs.edit().remove(prefKey(d, key)).apply()
    }

    private fun prefKey(d: Device, key: String) = "${d.name}.$key"
}
