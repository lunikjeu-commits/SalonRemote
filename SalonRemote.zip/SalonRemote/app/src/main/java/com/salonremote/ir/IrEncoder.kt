package com.salonremote.ir

import kotlin.math.roundToInt

/**
 * Signal prêt pour ConsumerIrManager.
 * [first] est émis à l'appui, [repeat] est ré-émis toutes les [repeatDelayMs] ms tant que la touche est maintenue.
 */
class IrSignal(
    val frequency: Int,
    val first: IntArray,
    val repeat: IntArray,
    val repeatDelayMs: Long
)

object IrEncoder {

    fun encode(code: IrCode, toggle: Boolean = false): IrSignal? = when (code.protocol) {
        IrProtocol.NEC -> necFrame(
            intArrayOf(
                code.address and 0xFF, code.address.inv() and 0xFF,
                code.command and 0xFF, code.command.inv() and 0xFF
            )
        )
        IrProtocol.NEC_EXT -> necFrame(
            intArrayOf(
                code.address and 0xFF, (code.address shr 8) and 0xFF,
                code.command and 0xFF, code.command.inv() and 0xFF
            )
        )
        IrProtocol.NEC_RAW -> necFrame(
            intArrayOf(
                ((code.raw shr 24) and 0xFF).toInt(), ((code.raw shr 16) and 0xFF).toInt(),
                ((code.raw shr 8) and 0xFF).toInt(), (code.raw and 0xFF).toInt()
            )
        )
        IrProtocol.RC5 -> rc5Frame(code.address, code.command, toggle)
        IrProtocol.PRONTO -> prontoSignal(code.pronto)
    }

    private fun necFrame(bytes: IntArray): IrSignal {
        val p = ArrayList<Int>(70)
        p += 9000
        p += 4500
        for (b in bytes) {
            for (i in 0..7) {
                p += 560
                p += if (((b shr i) and 1) == 1) 1690 else 560
            }
        }
        p += 560
        p += 560 // espace final : longueur paire
        return IrSignal(38000, p.toIntArray(), intArrayOf(9000, 2250, 560, 560), 96L)
    }

    private fun rc5Frame(address: Int, command: Int, toggle: Boolean): IrSignal {
        val bits = ArrayList<Boolean>(14)
        bits += true
        bits += (command and 0x40) == 0 // 2e bit de start = NON bit 6 de commande (RC5 étendu)
        bits += toggle
        for (i in 4 downTo 0) bits += ((address shr i) and 1) == 1
        for (i in 5 downTo 0) bits += ((command shr i) and 1) == 1

        // Manchester : 1 = espace puis marque, 0 = marque puis espace
        val halves = ArrayList<Boolean>(28)
        for (b in bits) {
            if (b) { halves += false; halves += true } else { halves += true; halves += false }
        }
        halves.removeAt(0) // le motif doit commencer par une marque
        val out = ArrayList<Int>()
        var level = true
        var run = 0
        for (h in halves) {
            if (h == level) run++ else {
                out += run * 889
                level = h
                run = 1
            }
        }
        out += run * 889
        if (out.size % 2 == 1) out += 889 * 8
        val arr = out.toIntArray()
        return IrSignal(36000, arr, arr, 89L)
    }

    private fun prontoSignal(hex: String): IrSignal? {
        val w = hex.trim().split(Regex("\\s+")).mapNotNull { it.toIntOrNull(16) }
        if (w.size < 6 || w[0] != 0 || w[1] == 0) return null
        val period = w[1] * 0.241246
        val freq = (1_000_000.0 / period).roundToInt()
        val once = w[2]
        val rep = w[3]
        if (w.size < 4 + 2 * (once + rep)) return null
        fun slice(from: Int, pairs: Int) = IntArray(pairs * 2) { (w[from + it] * period).roundToInt() }
        val a = slice(4, once)
        val b = slice(4 + 2 * once, rep)
        val first = a + b
        if (first.isEmpty()) return null
        return IrSignal(freq, first, if (b.isNotEmpty()) b else first, 100L)
    }
}
