package com.salonremote.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import com.salonremote.RemoteViewModel

@Composable
fun RemoteApp(vm: RemoteViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showCalibration by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val message by vm.message.collectAsState()

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            if (showCalibration) {
                CalibrationScreen(vm, onBack = { showCalibration = false })
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TabRow(
                        selectedTabIndex = tab,
                        modifier = Modifier.weight(1f),
                        containerColor = MaterialTheme.colorScheme.background
                    ) {
                        listOf("TV Metz", "Barre Stage V2", "Projecteur Yaber").forEachIndexed { i, title ->
                            Tab(
                                selected = tab == i,
                                onClick = { tab = i },
                                text = { Text(title, fontSize = 12.sp, maxLines = 1) }
                            )
                        }
                    }
                    IconButton(onClick = { showCalibration = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Réglages / Calibrage")
                    }
                }
                when (tab) {
                    0 -> TvMetzScreen(vm)
                    1 -> SoundbarScreen(vm)
                    else -> ProjectorScreen(vm)
                }
            }
        }
    }
}
