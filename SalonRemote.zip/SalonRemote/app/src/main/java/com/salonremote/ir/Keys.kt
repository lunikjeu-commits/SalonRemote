package com.salonremote.ir

/** Identifiants de touches partagés par l'UI, les bases de codes et le mode Wi-Fi. */
object Keys {
    const val POWER = "POWER"
    const val MUTE = "MUTE"
    const val SRC_TV = "SRC_TV"
    const val HDMI1 = "HDMI1"
    const val HDMI2 = "HDMI2"
    const val HDMI3 = "HDMI3"
    const val USB = "USB"
    const val UP = "UP"
    const val DOWN = "DOWN"
    const val LEFT = "LEFT"
    const val RIGHT = "RIGHT"
    const val OK = "OK"
    const val BACK = "BACK"
    const val HOME = "HOME"
    const val MENU = "MENU"
    const val INFO = "INFO"
    const val VOL_UP = "VOL_UP"
    const val VOL_DOWN = "VOL_DOWN"
    const val CH_UP = "CH_UP"
    const val CH_DOWN = "CH_DOWN"
    const val N0 = "N0"
    const val N1 = "N1"
    const val N2 = "N2"
    const val N3 = "N3"
    const val N4 = "N4"
    const val N5 = "N5"
    const val N6 = "N6"
    const val N7 = "N7"
    const val N8 = "N8"
    const val N9 = "N9"
    const val RED = "RED"
    const val GREEN = "GREEN"
    const val YELLOW = "YELLOW"
    const val BLUE = "BLUE"

    // Barre de son
    const val IN_ARC = "IN_ARC"
    const val IN_BT = "IN_BT"
    const val IN_OPT = "IN_OPT"
    const val IN_USB = "IN_USB"
    const val IN_AUX = "IN_AUX"
    const val PLAY_PAUSE = "PLAY_PAUSE"
    const val PREV = "PREV"
    const val NEXT = "NEXT"
    const val BASS_UP = "BASS_UP"
    const val BASS_DOWN = "BASS_DOWN"
    const val TREBLE_UP = "TREBLE_UP"
    const val TREBLE_DOWN = "TREBLE_DOWN"
    const val SURROUND = "SURROUND"
    const val DIALOG = "DIALOG"

    // Projecteur
    const val SOURCE = "SOURCE"
    const val AV = "AV"
    const val MIRROR = "MIRROR"
    const val FLIP = "FLIP"
    const val KEYSTONE_UP = "KEYSTONE_UP"
    const val KEYSTONE_DOWN = "KEYSTONE_DOWN"
    const val ZOOM_UP = "ZOOM_UP"
    const val ZOOM_DOWN = "ZOOM_DOWN"

    /** Touches répétées tant que le doigt reste appuyé. */
    val REPEATABLE: Set<String> = setOf(
        VOL_UP, VOL_DOWN, CH_UP, CH_DOWN, UP, DOWN, LEFT, RIGHT,
        BASS_UP, BASS_DOWN, TREBLE_UP, TREBLE_DOWN,
        KEYSTONE_UP, KEYSTONE_DOWN, ZOOM_UP, ZOOM_DOWN
    )
}
