package com.salonremote.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AmoledScheme = darkColorScheme(
    primary = Color(0xFF4FC3F7),
    onPrimary = Color.Black,
    secondaryContainer = Color(0xFF1F3A47),
    onSecondaryContainer = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFFE0E0E0),
    surfaceContainerHigh = Color(0xFF121214),
    error = Color(0xFFD32F2F)
)

@Composable
fun SalonRemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AmoledScheme, content = content)
}
