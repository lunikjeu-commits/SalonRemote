package com.salonremote.ir

import android.content.Context
import android.hardware.ConsumerIrManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Moteur d'émission IR : encode NEC / RC5 / Pronto et pilote ConsumerIrManager.transmit(). */
class IrTransmitterManager(context: Context) {

    private val manager: ConsumerIrManager? =
        context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var holdJob: Job? = null
    private var toggle = false

    val hasEmitter: Boolean
        get() = try { manager?.hasIrEmitter() == true } catch (e: Exception) { false }

    /** Envoie la trame ; si [repeatable], la répète jusqu'à [stopHold]. */
    fun startHold(code: IrCode, repeatable: Boolean): Boolean {
        stopHold()
        toggle = !toggle
        val signal = IrEncoder.encode(code, toggle) ?: return false
        if (!hasEmitter) return false
        holdJob = scope.launch {
            transmit(signal.frequency, signal.first)
            if (!repeatable) return@launch
            delay(signal.repeatDelayMs)
            while (isActive) {
                transmit(signal.frequency, signal.repeat)
                delay(signal.repeatDelayMs)
            }
        }
        return true
    }

    fun stopHold() {
        holdJob?.cancel()
        holdJob = null
    }

    private fun transmit(frequency: Int, pattern: IntArray) {
        try {
            manager?.transmit(frequency, pattern)
        } catch (e: Exception) {
            // émetteur occupé ou fréquence refusée : on ignore cette trame
        }
    }

    fun release() {
        stopHold()
        scope.cancel()
    }
}
