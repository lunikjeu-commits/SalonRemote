package com.salonremote.ir.codes

import com.salonremote.ir.IrCode
import com.salonremote.ir.Keys
import com.salonremote.ir.nec

/**
 * TV Metz MUC61 (plateforme Skyworth, Android TV).
 * VALEURS DE DÉPART : à valider/ajuster via l'écran Calibrage (les codes sont modifiables et sauvegardés).
 */
object MetzCodes {
    const val ADDR = 0x00

    val codes: Map<String, IrCode> = linkedMapOf(
        Keys.POWER to nec(ADDR, 0x08),
        Keys.MUTE to nec(ADDR, 0x09),
        Keys.SRC_TV to nec(ADDR, 0x0A),
        Keys.HDMI1 to nec(ADDR, 0x0B),
        Keys.HDMI2 to nec(ADDR, 0x0C),
        Keys.HDMI3 to nec(ADDR, 0x0D),
        Keys.USB to nec(ADDR, 0x0E),
        Keys.UP to nec(ADDR, 0x40),
        Keys.DOWN to nec(ADDR, 0x41),
        Keys.LEFT to nec(ADDR, 0x42),
        Keys.RIGHT to nec(ADDR, 0x43),
        Keys.OK to nec(ADDR, 0x44),
        Keys.BACK to nec(ADDR, 0x45),
        Keys.HOME to nec(ADDR, 0x46),
        Keys.MENU to nec(ADDR, 0x47),
        Keys.INFO to nec(ADDR, 0x48),
        Keys.VOL_UP to nec(ADDR, 0x10),
        Keys.VOL_DOWN to nec(ADDR, 0x11),
        Keys.CH_UP to nec(ADDR, 0x12),
        Keys.CH_DOWN to nec(ADDR, 0x13),
        Keys.N0 to nec(ADDR, 0x20),
        Keys.N1 to nec(ADDR, 0x21),
        Keys.N2 to nec(ADDR, 0x22),
        Keys.N3 to nec(ADDR, 0x23),
        Keys.N4 to nec(ADDR, 0x24),
        Keys.N5 to nec(ADDR, 0x25),
        Keys.N6 to nec(ADDR, 0x26),
        Keys.N7 to nec(ADDR, 0x27),
        Keys.N8 to nec(ADDR, 0x28),
        Keys.N9 to nec(ADDR, 0x29),
        Keys.RED to nec(ADDR, 0x50),
        Keys.GREEN to nec(ADDR, 0x51),
        Keys.YELLOW to nec(ADDR, 0x52),
        Keys.BLUE to nec(ADDR, 0x53)
    )
}
