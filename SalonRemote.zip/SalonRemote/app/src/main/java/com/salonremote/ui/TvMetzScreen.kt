package com.salonremote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salonremote.RemoteViewModel
import com.salonremote.TvMode
import com.salonremote.ir.Device
import com.salonremote.ir.Keys

private val D = Device.TV

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TvMetzScreen(vm: RemoteViewModel) {
    val mode by vm.tvMode.collectAsState()
    var showNumPad by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key(vm, D, Keys.POWER, Modifier.weight(1f).height(60.dp), container = Color(0xFFD32F2F)) {
                KeyIcon(Icons.Filled.PowerSettingsNew, "Power")
            }
            Key(vm, D, Keys.MUTE, Modifier.weight(1f).height(60.dp)) {
                KeyIcon(Icons.Filled.VolumeOff, "Mute")
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Mode", fontSize = 13.sp)
            FilterChip(selected = mode == TvMode.IR, onClick = { vm.setTvMode(TvMode.IR) }, label = { Text("IR") })
            FilterChip(selected = mode == TvMode.WIFI, onClick = { vm.setTvMode(TvMode.WIFI) }, label = { Text("Wi-Fi") })
        }
        SourceRow(
            vm, D,
            listOf(
                Keys.SRC_TV to "TV", Keys.HDMI1 to "HDMI 1", Keys.HDMI2 to "HDMI 2",
                Keys.HDMI3 to "HDMI 3", Keys.USB to "USB"
            )
        )
        DPadBlock(
            vm, D,
            listOf(Keys.BACK to "Retour", Keys.HOME to "Accueil", Keys.MENU to "Menu TV", Keys.INFO to "Info")
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Rocker(vm, D, Keys.VOL_UP, Keys.VOL_DOWN, "VOL", Modifier.weight(1f))
            RemoteButton(onDown = { showNumPad = true }, modifier = Modifier.weight(1f).height(72.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    KeyIcon(Icons.Filled.Dialpad, "123", 22)
                    KeyLabel("123")
                }
            }
            Rocker(vm, D, Keys.CH_UP, Keys.CH_DOWN, "CH", Modifier.weight(1f))
        }
    }

    if (showNumPad) {
        ModalBottomSheet(onDismissRequest = { showNumPad = false }) {
            NumPad(vm)
        }
    }
}

@Composable
private fun NumPad(vm: RemoteViewModel) {
    val rows = listOf(
        listOf(Keys.N1 to "1", Keys.N2 to "2", Keys.N3 to "3"),
        listOf(Keys.N4 to "4", Keys.N5 to "5", Keys.N6 to "6"),
        listOf(Keys.N7 to "7", Keys.N8 to "8", Keys.N9 to "9")
    )
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (k, l) -> Key(vm, D, k, Modifier.weight(1f).height(58.dp)) { KeyLabel(l, 20.sp) } }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f)) {}
            Key(vm, D, Keys.N0, Modifier.weight(1f).height(58.dp)) { KeyLabel("0", 20.sp) }
            Row(Modifier.weight(1f)) {}
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key(vm, D, Keys.RED, Modifier.weight(1f).height(44.dp), container = Color(0xFFD32F2F)) {}
            Key(vm, D, Keys.GREEN, Modifier.weight(1f).height(44.dp), container = Color(0xFF2E7D32)) {}
            Key(vm, D, Keys.YELLOW, Modifier.weight(1f).height(44.dp), container = Color(0xFFF9A825)) {}
            Key(vm, D, Keys.BLUE, Modifier.weight(1f).height(44.dp), container = Color(0xFF1565C0)) {}
        }
    }
}
