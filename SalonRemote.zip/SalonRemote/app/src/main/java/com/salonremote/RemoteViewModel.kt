package com.salonremote

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.salonremote.ir.Device
import com.salonremote.ir.IrCode
import com.salonremote.ir.IrCodeRepository
import com.salonremote.ir.IrTransmitterManager
import com.salonremote.ir.Keys
import com.salonremote.wifi.AndroidTvRemoteClient
import com.salonremote.wifi.WifiKeys
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class TvMode { IR, WIFI }

class RemoteViewModel(app: Application) : AndroidViewModel(app) {

    val repo = IrCodeRepository(app)
    private val ir = IrTransmitterManager(app)
    val wifi = AndroidTvRemoteClient(app)
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val hasEmitter: Boolean = ir.hasEmitter
    val tvMode = MutableStateFlow(if (prefs.getString("tv_mode", "IR") == "WIFI") TvMode.WIFI else TvMode.IR)
    val tvHost = MutableStateFlow(prefs.getString("tv_host", "") ?: "")
    val message = MutableStateFlow<String?>(null)

    fun clearMessage() { message.value = null }

    fun setTvMode(mode: TvMode) {
        tvMode.value = mode
        prefs.edit().putString("tv_mode", mode.name).apply()
        if (mode == TvMode.WIFI) connectWifi()
    }

    fun setTvHost(host: String) {
        tvHost.value = host.trim()
        prefs.edit().putString("tv_host", host.trim()).apply()
    }

    // ---------- Appui sur une touche ----------

    fun pressDown(device: Device, key: String) {
        if (device == Device.TV && tvMode.value == TvMode.WIFI) {
            wifiKey(key, true)
            return
        }
        val code = repo.get(device, key) ?: return
        if (!ir.hasEmitter) {
            message.value = "Aucun émetteur IR détecté sur cet appareil."
            return
        }
        if (!ir.startHold(code, key in Keys.REPEATABLE)) {
            message.value = "Code IR invalide pour « $key » : corrigez-le dans Calibrage."
        }
    }

    fun pressUp(device: Device, key: String) {
        if (device == Device.TV && tvMode.value == TvMode.WIFI) {
            wifiKey(key, false)
            return
        }
        ir.stopHold()
    }

    // ---------- Calibrage ----------

    fun testCode(code: IrCode, repeat: Boolean = false): Boolean {
        if (!ir.hasEmitter) {
            message.value = "Aucun émetteur IR détecté sur cet appareil."
            return false
        }
        val ok = ir.startHold(code, repeat)
        if (!ok) message.value = "Code IR invalide."
        return ok
    }

    fun stopTest() = ir.stopHold()

    fun saveCode(device: Device, key: String, code: IrCode) {
        repo.set(device, key, code)
        message.value = "Code enregistré : ${code.toText()}"
    }

    fun resetCode(device: Device, key: String) {
        repo.reset(device, key)
        message.value = "Code par défaut restauré."
    }

    // ---------- Wi-Fi (Android TV Remote v2) ----------

    fun startPairing() {
        val host = tvHost.value
        if (host.isBlank()) { message.value = "Saisissez l'adresse IP de la TV."; return }
        viewModelScope.launch { wifi.startPairing(host) }
    }

    fun submitPairingCode(code: String) {
        viewModelScope.launch { wifi.submitCode(code) }
    }

    fun connectWifi() {
        val host = tvHost.value
        if (host.isBlank()) { message.value = "Saisissez l'IP de la TV dans Réglages / Calibrage."; return }
        viewModelScope.launch { wifi.connect(host) }
    }

    private fun wifiKey(key: String, down: Boolean) {
        val keyCode = WifiKeys.map[key] ?: return
        val repeatable = key in Keys.REPEATABLE
        if (!repeatable && !down) return
        val direction = if (repeatable) (if (down) 1 else 2) else 3
        viewModelScope.launch {
            if (wifi.state.value != AndroidTvRemoteClient.State.CONNECTED) {
                if (!down) return@launch
                if (tvHost.value.isBlank()) {
                    message.value = "Saisissez l'IP de la TV dans Réglages / Calibrage."
                    return@launch
                }
                wifi.connect(tvHost.value)
            }
            if (wifi.state.value == AndroidTvRemoteClient.State.CONNECTED) {
                wifi.sendKey(keyCode, direction)
            } else {
                message.value = wifi.info.value
            }
        }
    }

    override fun onCleared() {
        ir.release()
        wifi.disconnect()
    }
}
