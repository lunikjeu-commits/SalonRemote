package com.salonremote.ir.codes

import com.salonremote.ir.IrCode
import com.salonremote.ir.Keys
import com.salonremote.ir.nec

/**
 * Barre de son Creative Stage V2 (NEC).
 * VALEURS DE DÉPART : à valider/ajuster via l'écran Calibrage.
 */
object CreativeStageCodes {
    const val ADDR = 0x80

    val codes: Map<String, IrCode> = linkedMapOf(
        Keys.POWER to nec(ADDR, 0x01),
        Keys.MUTE to nec(ADDR, 0x02),
        Keys.IN_ARC to nec(ADDR, 0x03),
        Keys.IN_BT to nec(ADDR, 0x04),
        Keys.IN_OPT to nec(ADDR, 0x05),
        Keys.IN_USB to nec(ADDR, 0x06),
        Keys.IN_AUX to nec(ADDR, 0x07),
        Keys.VOL_UP to nec(ADDR, 0x08),
        Keys.VOL_DOWN to nec(ADDR, 0x09),
        Keys.PLAY_PAUSE to nec(ADDR, 0x0A),
        Keys.PREV to nec(ADDR, 0x0B),
        Keys.NEXT to nec(ADDR, 0x0C),
        Keys.BASS_UP to nec(ADDR, 0x0D),
        Keys.BASS_DOWN to nec(ADDR, 0x0E),
        Keys.TREBLE_UP to nec(ADDR, 0x0F),
        Keys.TREBLE_DOWN to nec(ADDR, 0x10),
        Keys.SURROUND to nec(ADDR, 0x11),
        Keys.DIALOG to nec(ADDR, 0x12)
    )
}
