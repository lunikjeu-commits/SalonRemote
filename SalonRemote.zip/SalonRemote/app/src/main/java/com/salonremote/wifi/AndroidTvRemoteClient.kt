package com.salonremote.wifi

import android.annotation.SuppressLint
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.salonremote.ir.Keys
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.security.auth.x500.X500Principal

/** Correspondance touches de l'app -> KeyEvent Android (protocole Android TV Remote v2). */
object WifiKeys {
    val map: Map<String, Int> = mapOf(
        Keys.POWER to 26, Keys.MUTE to 164, Keys.SRC_TV to 170,
        Keys.HDMI1 to 243, Keys.HDMI2 to 244, Keys.HDMI3 to 245, Keys.USB to 178,
        Keys.UP to 19, Keys.DOWN to 20, Keys.LEFT to 21, Keys.RIGHT to 22, Keys.OK to 23,
        Keys.BACK to 4, Keys.HOME to 3, Keys.MENU to 82, Keys.INFO to 165,
        Keys.VOL_UP to 24, Keys.VOL_DOWN to 25, Keys.CH_UP to 166, Keys.CH_DOWN to 167,
        Keys.N0 to 7, Keys.N1 to 8, Keys.N2 to 9, Keys.N3 to 10, Keys.N4 to 11,
        Keys.N5 to 12, Keys.N6 to 13, Keys.N7 to 14, Keys.N8 to 15, Keys.N9 to 16,
        Keys.RED to 183, Keys.GREEN to 184, Keys.YELLOW to 185, Keys.BLUE to 186
    )
}

/**
 * Client minimaliste du protocole Android TV Remote v2 (appairage 6467, télécommande 6466),
 * sans dépendance externe : TLS avec certificat client auto-signé (Android Keystore) et protobuf écrit à la main.
 */
class AndroidTvRemoteClient(@Suppress("unused") private val context: Context) {

    enum class State { IDLE, PAIRING_CONNECTING, WAITING_CODE, PAIRED, CONNECTING, CONNECTED, ERROR }

    val state = MutableStateFlow(State.IDLE)
    val info = MutableStateFlow("")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pairingSocket: SSLSocket? = null
    private var remoteSocket: SSLSocket? = null
    private var readerJob: Job? = null
    private val writeLock = Any()

    // ---------- Certificat client ----------

    private fun keyStore(): KeyStore {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        if (!ks.containsAlias(ALIAS)) {
            val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            gen.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setKeySize(2048)
                    .setDigests(
                        KeyProperties.DIGEST_NONE, KeyProperties.DIGEST_SHA1,
                        KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA384, KeyProperties.DIGEST_SHA512
                    )
                    .setSignaturePaddings(
                        KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS
                    )
                    .setCertificateSubject(X500Principal("CN=salonremote"))
                    .setCertificateSerialNumber(BigInteger.ONE)
                    .setCertificateNotBefore(Date())
                    .setCertificateNotAfter(Date(System.currentTimeMillis() + 20L * 365 * 24 * 3600 * 1000))
                    .build()
            )
            gen.generateKeyPair()
        }
        return ks
    }

    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    private object TrustAll : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    private fun open(host: String, port: Int): SSLSocket {
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore(), null)
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf<TrustManager>(TrustAll), SecureRandom())
        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 5000)
        val s = ctx.socketFactory.createSocket(raw, host, port, true) as SSLSocket
        s.soTimeout = 15000
        s.startHandshake()
        return s
    }

    // ---------- Protobuf minimal ----------

    internal object Pb {
        class Field(val num: Int, val value: Long, val data: ByteArray?)

        fun varint(value: Long): ByteArray {
            var v = value
            val o = ByteArrayOutputStream()
            while (true) {
                if ((v and 0x7FL.inv()) == 0L) {
                    o.write(v.toInt())
                    break
                }
                o.write(((v and 0x7FL) or 0x80L).toInt())
                v = v ushr 7
            }
            return o.toByteArray()
        }

        fun int(field: Int, v: Int): ByteArray = varint((field shl 3).toLong()) + varint(v.toLong())
        fun bytes(field: Int, b: ByteArray): ByteArray =
            varint(((field shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
        fun str(field: Int, s: String): ByteArray = bytes(field, s.toByteArray())

        fun parse(b: ByteArray): List<Field> {
            val out = ArrayList<Field>()
            var i = 0
            fun readVarint(): Long {
                var r = 0L
                var shift = 0
                while (true) {
                    val x = b[i++].toInt() and 0xFF
                    r = r or ((x and 0x7F).toLong() shl shift)
                    if ((x and 0x80) == 0) break
                    shift += 7
                }
                return r
            }
            while (i < b.size) {
                val tag = readVarint()
                val num = (tag shr 3).toInt()
                when ((tag and 7L).toInt()) {
                    0 -> out += Field(num, readVarint(), null)
                    2 -> {
                        val n = readVarint().toInt()
                        out += Field(num, 0L, b.copyOfRange(i, i + n))
                        i += n
                    }
                    1 -> i += 8
                    5 -> i += 4
                    else -> return out
                }
            }
            return out
        }
    }

    private fun write(s: SSLSocket, payload: ByteArray) {
        synchronized(writeLock) {
            val o = s.outputStream
            o.write(Pb.varint(payload.size.toLong()) + payload)
            o.flush()
        }
    }

    private fun read(s: SSLSocket): ByteArray {
        val input = s.inputStream
        var len = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) throw IOException("Connexion fermée par la TV")
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) throw IOException("Connexion fermée par la TV")
            off += n
        }
        return buf
    }

    private fun outer(field: Int, body: ByteArray): ByteArray =
        Pb.int(1, 2) + Pb.int(2, 200) + Pb.bytes(field, body)

    private fun expect(raw: ByteArray, field: Int) {
        val f = Pb.parse(raw)
        val status = f.firstOrNull { it.num == 2 }?.value ?: 200L
        if (status != 200L) throw IOException("Refus de la TV (statut $status)")
        if (f.none { it.num == field }) throw IOException("Réponse inattendue de la TV")
    }

    // ---------- Appairage (port 6467) ----------

    suspend fun startPairing(host: String) = withContext(Dispatchers.IO) {
        try {
            closePairing()
            state.value = State.PAIRING_CONNECTING
            info.value = "Connexion à $host…"
            val s = open(host, 6467)
            pairingSocket = s
            write(s, outer(10, Pb.str(1, "atvremote") + Pb.str(2, "Salon Remote")))
            expect(read(s), 11)
            val enc = Pb.int(1, 3) + Pb.int(2, 6) // HEXADECIMAL, 6 symboles
            write(s, outer(20, Pb.bytes(1, enc) + Pb.bytes(2, enc) + Pb.int(3, 1)))
            expect(read(s), 20)
            write(s, outer(30, Pb.bytes(1, enc) + Pb.int(2, 1)))
            expect(read(s), 31)
            state.value = State.WAITING_CODE
            info.value = "Saisissez le code à 6 caractères affiché sur la TV."
        } catch (e: Exception) {
            closePairing()
            state.value = State.ERROR
            info.value = "Appairage impossible : ${e.message}"
        }
    }

    suspend fun submitCode(code: String) = withContext(Dispatchers.IO) {
        try {
            val s = pairingSocket ?: throw IOException("Lancez d'abord l'appairage")
            val c = code.trim().uppercase()
            if (c.length != 6 || !c.all { it in '0'..'9' || it in 'A'..'F' }) {
                throw IOException("Le code doit contenir 6 caractères hexadécimaux")
            }
            val client = keyStore().getCertificate(ALIAS).publicKey as RSAPublicKey
            val server = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
            val md = MessageDigest.getInstance("SHA-256")
            md.update(hexBytes(client.modulus))
            md.update(hexBytes(client.publicExponent))
            md.update(hexBytes(server.modulus))
            md.update(hexBytes(server.publicExponent))
            md.update(c.substring(2).chunked(2).map { it.toInt(16).toByte() }.toByteArray())
            val hash = md.digest()
            if ((hash[0].toInt() and 0xFF) != c.substring(0, 2).toInt(16)) throw IOException("Code incorrect")
            write(s, outer(40, Pb.bytes(1, hash)))
            expect(read(s), 41)
            closePairing()
            state.value = State.PAIRED
            info.value = "TV appairée. Vous pouvez la piloter en Wi-Fi."
        } catch (e: Exception) {
            closePairing()
            state.value = State.ERROR
            info.value = "Échec de l'appairage : ${e.message}"
        }
    }

    private fun hexBytes(n: BigInteger): ByteArray {
        var h = n.toString(16)
        if (h.length % 2 == 1) h = "0$h"
        return h.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }

    private fun closePairing() {
        try { pairingSocket?.close() } catch (_: Exception) {}
        pairingSocket = null
    }

    // ---------- Télécommande (port 6466) ----------

    suspend fun connect(host: String) = withContext(Dispatchers.IO) {
        try {
            disconnect()
            state.value = State.CONNECTING
            info.value = "Connexion à $host…"
            val s = open(host, 6466)
            s.soTimeout = 0
            remoteSocket = s
            readerJob = scope.launch {
                try {
                    while (isActive) {
                        for (f in Pb.parse(read(s))) {
                            when (f.num) {
                                1 -> write(s, configureMessage())
                                2 -> {
                                    write(s, Pb.bytes(2, Pb.int(1, 622)))
                                    state.value = State.CONNECTED
                                    info.value = "Connecté en Wi-Fi."
                                }
                                8 -> {
                                    val v = f.data?.let { d -> Pb.parse(d).firstOrNull { it.num == 1 }?.value } ?: 1L
                                    write(s, Pb.bytes(9, Pb.int(1, v.toInt())))
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (state.value == State.CONNECTED || state.value == State.CONNECTING) {
                        state.value = State.ERROR
                        info.value = "Connexion Wi-Fi perdue (TV éteinte ou non appairée ?)"
                    }
                }
            }
            withTimeoutOrNull(6000) { state.first { it == State.CONNECTED || it == State.ERROR } }
            if (state.value == State.CONNECTING) {
                state.value = State.ERROR
                info.value = "Pas de réponse de la TV."
            }
        } catch (e: Exception) {
            state.value = State.ERROR
            info.value = "Connexion impossible : ${e.message}. Appairez d'abord la TV."
        }
    }

    private fun configureMessage(): ByteArray {
        val device = Pb.str(1, "Salon Remote") + Pb.str(2, "Salon") + Pb.int(3, 1) +
            Pb.str(4, "1") + Pb.str(5, "com.salonremote") + Pb.str(6, "1.0.0")
        return Pb.bytes(1, Pb.int(1, 622) + Pb.bytes(2, device))
    }

    /** direction : 1 = début d'appui long, 2 = fin d'appui long, 3 = appui court. */
    suspend fun sendKey(keyCode: Int, direction: Int) = withContext(Dispatchers.IO) {
        try {
            val s = remoteSocket ?: return@withContext
            write(s, Pb.bytes(10, Pb.int(1, keyCode) + Pb.int(2, direction)))
        } catch (e: Exception) {
            state.value = State.ERROR
            info.value = "Envoi impossible : ${e.message}"
        }
    }

    fun disconnect() {
        readerJob?.cancel()
        readerJob = null
        try { remoteSocket?.close() } catch (_: Exception) {}
        remoteSocket = null
        closePairing()
    }

    companion object {
        private const val ALIAS = "salonremote_tv_client"
    }
}
