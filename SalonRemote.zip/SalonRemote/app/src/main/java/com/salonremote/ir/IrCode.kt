package com.salonremote.ir

enum class IrProtocol { NEC, NEC_EXT, NEC_RAW, RC5, PRONTO }

/**
 * Description d'une trame IR (indépendante de la modulation).
 * - NEC      : adresse 8 bits + commande 8 bits (compléments ajoutés automatiquement)
 * - NEC_EXT  : adresse 16 bits (octet bas puis haut) + commande 8 bits
 * - NEC_RAW  : 32 bits bruts, octets envoyés de gauche à droite, chaque octet LSB en premier
 * - RC5      : adresse 5 bits + commande 6/7 bits (36 kHz)
 * - PRONTO   : code Pronto Hex (« 0000 006D ... »)
 */
data class IrCode(
    val protocol: IrProtocol,
    val address: Int = 0,
    val command: Int = 0,
    val raw: Long = 0L,
    val pronto: String = ""
) {
    fun toText(): String = when (protocol) {
        IrProtocol.NEC -> "NEC:0x%02X:0x%02X".format(address and 0xFF, command and 0xFF)
        IrProtocol.NEC_EXT -> "NECX:0x%04X:0x%02X".format(address and 0xFFFF, command and 0xFF)
        IrProtocol.NEC_RAW -> "NEC32:0x%08X".format(raw and 0xFFFFFFFFL)
        IrProtocol.RC5 -> "RC5:0x%02X:0x%02X".format(address and 0x1F, command and 0x7F)
        IrProtocol.PRONTO -> "PRONTO:$pronto"
    }

    companion object {
        private val prontoOnly = Regex("^[0-9A-Fa-f]{4}(\\s+[0-9A-Fa-f]{4})+$")

        fun parse(text: String): IrCode? {
            val t = text.trim()
            if (t.isEmpty()) return null
            if (prontoOnly.matches(t)) return IrCode(IrProtocol.PRONTO, pronto = t.uppercase())

            val idx = t.indexOfFirst { it == ':' || it.isWhitespace() }
            val head = (if (idx < 0) t else t.substring(0, idx)).uppercase()
            val rest = if (idx < 0) "" else t.substring(idx + 1).trim()

            if (head == "PRONTO") {
                return if (prontoOnly.matches(rest)) IrCode(IrProtocol.PRONTO, pronto = rest.uppercase()) else null
            }
            val n: List<Long?> = rest.split(Regex("[:,\\s]+"))
                .filter { it.isNotEmpty() }
                .map { it.removePrefix("0x").removePrefix("0X").toLongOrNull(16) }
            if (n.isEmpty() || n.any { it == null }) return null
            val a = n[0]!!
            val c = n.getOrNull(1)
            return when (head) {
                "NEC" -> if (c == null) null else IrCode(IrProtocol.NEC, (a and 0xFF).toInt(), (c and 0xFF).toInt())
                "NECX", "NEC_EXT" -> if (c == null) null else IrCode(IrProtocol.NEC_EXT, (a and 0xFFFF).toInt(), (c and 0xFF).toInt())
                "NEC32", "NEC_RAW" -> IrCode(IrProtocol.NEC_RAW, raw = a and 0xFFFFFFFFL)
                "RC5" -> if (c == null) null else IrCode(IrProtocol.RC5, (a and 0x1F).toInt(), (c and 0x7F).toInt())
                else -> null
            }
        }
    }
}

fun nec(address: Int, command: Int) = IrCode(IrProtocol.NEC, address, command)
fun necExt(address: Int, command: Int) = IrCode(IrProtocol.NEC_EXT, address, command)
fun rc5(address: Int, command: Int) = IrCode(IrProtocol.RC5, address, command)
fun pronto(hex: String) = IrCode(IrProtocol.PRONTO, pronto = hex.trim().uppercase())
