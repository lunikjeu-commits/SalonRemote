package com.salonremote.ir.codes

import com.salonremote.ir.IrCode
import com.salonremote.ir.Keys
import com.salonremote.ir.nec

/**
 * Vidéoprojecteur Yaber Pro V7 (NEC).
 * VALEURS DE DÉPART : à valider/ajuster via l'écran Calibrage.
 * SOURCE fait défiler les entrées ; HDMI1/HDMI2/AV/USB/MIRROR sont des accès directs à calibrer
 * (si la télécommande d'origine n'en a pas, réglez-les avec le même code que SOURCE).
 */
object YaberCodes {
    const val ADDR = 0x00

    val codes: Map<String, IrCode> = linkedMapOf(
        Keys.POWER to nec(ADDR, 0x1A),
        Keys.SOURCE to nec(ADDR, 0x1B),
        Keys.HDMI1 to nec(ADDR, 0x1C),
        Keys.HDMI2 to nec(ADDR, 0x1D),
        Keys.AV to nec(ADDR, 0x1E),
        Keys.USB to nec(ADDR, 0x1F),
        Keys.MIRROR to nec(ADDR, 0x30),
        Keys.MUTE to nec(ADDR, 0x31),
        Keys.UP to nec(ADDR, 0x32),
        Keys.DOWN to nec(ADDR, 0x33),
        Keys.LEFT to nec(ADDR, 0x34),
        Keys.RIGHT to nec(ADDR, 0x35),
        Keys.OK to nec(ADDR, 0x36),
        Keys.BACK to nec(ADDR, 0x37),
        Keys.MENU to nec(ADDR, 0x38),
        Keys.HOME to nec(ADDR, 0x39),
        Keys.FLIP to nec(ADDR, 0x3A),
        Keys.VOL_UP to nec(ADDR, 0x3B),
        Keys.VOL_DOWN to nec(ADDR, 0x3C),
        Keys.KEYSTONE_UP to nec(ADDR, 0x3D),
        Keys.KEYSTONE_DOWN to nec(ADDR, 0x3E),
        Keys.ZOOM_UP to nec(ADDR, 0x3F),
        Keys.ZOOM_DOWN to nec(ADDR, 0x2F)
    )
}
