package com.salonremote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salonremote.RemoteViewModel
import com.salonremote.ir.Device
import com.salonremote.ir.IrCode
import com.salonremote.ir.IrProtocol
import com.salonremote.wifi.AndroidTvRemoteClient

@Composable
fun CalibrationScreen(vm: RemoteViewModel, onBack: () -> Unit) {
    var device by remember { mutableStateOf(Device.TV) }
    var key by remember { mutableStateOf(vm.repo.keys(Device.TV).first()) }
    var menuOpen by remember { mutableStateOf(false) }
    var codeText by remember { mutableStateOf(vm.repo.get(Device.TV, key)?.toText().orEmpty()) }

    fun loadKey(d: Device, k: String) {
        device = d
        key = k
        codeText = vm.repo.get(d, k)?.toText().orEmpty()
    }

    // Variantes / balayage
    var proto by remember { mutableStateOf(IrProtocol.NEC) }
    var addr by remember { mutableStateOf("00") }
    var cmd by remember { mutableStateOf("00") }

    fun sweepCode(): IrCode? {
        val a = addr.trim().removePrefix("0x").toIntOrNull(16) ?: return null
        val c = cmd.trim().removePrefix("0x").toIntOrNull(16) ?: return null
        return IrCode(proto, address = a, command = c)
    }

    fun stepCmd(delta: Int) {
        val c = cmd.trim().removePrefix("0x").toIntOrNull(16) ?: 0
        val limit = if (proto == IrProtocol.RC5) 0x7F else 0xFF
        val next = (c + delta).coerceIn(0, limit)
        cmd = "%02X".format(next)
        sweepCode()?.let { vm.testCode(it) }
    }

    // Wi-Fi
    val host by vm.tvHost.collectAsState()
    val wifiState by vm.wifi.state.collectAsState()
    val wifiInfo by vm.wifi.info.collectAsState()
    var pairCode by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
            Text("Réglages / Calibrage", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            if (vm.hasEmitter) "Émetteur IR détecté." else "Aucun émetteur IR détecté : l'envoi IR est désactivé.",
            color = if (vm.hasEmitter) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            fontSize = 13.sp
        )

        Text("1. Test d'une touche", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Device.values().forEach { d ->
                FilterChip(
                    selected = device == d,
                    onClick = { loadKey(d, vm.repo.keys(d).first()) },
                    label = { Text(d.title, fontSize = 11.sp, maxLines = 1) }
                )
            }
        }
        Box {
            OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Touche : $key" + if (vm.repo.isCustom(device, key)) "  (personnalisée)" else "")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                vm.repo.keys(device).forEach { k ->
                    DropdownMenuItem(text = { Text(k) }, onClick = { menuOpen = false; loadKey(device, k) })
                }
            }
        }
        OutlinedTextField(
            value = codeText,
            onValueChange = { codeText = it },
            label = { Text("Code (NEC / NECX / NEC32 / RC5 / PRONTO)") },
            supportingText = {
                Text("Ex. NEC:0x00:0x08 · NECX:0x1234:0x08 · NEC32:0x00FF08F7 · RC5:0x05:0x0C · PRONTO:0000 006D …")
            },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val c = IrCode.parse(codeText)
                if (c == null) vm.message.value = "Format de code invalide." else vm.testCode(c)
            }) { Text("Tester") }
            Button(onClick = {
                val c = IrCode.parse(codeText)
                if (c == null) vm.message.value = "Format de code invalide." else vm.saveCode(device, key, c)
            }) { Text("Enregistrer") }
            OutlinedButton(onClick = {
                vm.resetCode(device, key)
                loadKey(device, key)
            }) { Text("Défaut") }
        }

        HorizontalDivider()
        Text("2. Variantes / balayage de commandes", fontWeight = FontWeight.Bold)
        Text(
            "Choisissez un format, réglez l'adresse puis faites défiler les commandes avec − / + : " +
                "chaque pression envoie la trame. Quand l'appareil réagit, copiez le code vers la touche.",
            fontSize = 12.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(IrProtocol.NEC to "NEC", IrProtocol.NEC_EXT to "NEC étendu", IrProtocol.RC5 to "RC5").forEach { (p, l) ->
                FilterChip(selected = proto == p, onClick = { proto = p }, label = { Text(l, fontSize = 12.sp) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = addr, onValueChange = { addr = it.take(4) },
                label = { Text("Adresse (hex)") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = cmd, onValueChange = { cmd = it.take(2) },
                label = { Text("Commande (hex)") }, singleLine = true, modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { stepCmd(-1) }) { Text("− cmd") }
            Button(onClick = {
                val c = sweepCode()
                if (c == null) vm.message.value = "Valeurs hex invalides." else vm.testCode(c)
            }) {
                Text("Envoyer")
            }
            OutlinedButton(onClick = { stepCmd(1) }) { Text("+ cmd") }
        }
        Button(
            onClick = {
                val c = sweepCode()
                if (c == null) vm.message.value = "Valeurs hex invalides." else {
                    codeText = c.toText()
                    vm.message.value = "Code copié : utilisez « Enregistrer » pour la touche $key."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Utiliser ce code pour « $key »") }

        HorizontalDivider()
        Text("3. TV Metz en Wi-Fi (Android TV Remote v2)", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = host,
            onValueChange = { vm.setTvHost(it) },
            label = { Text("Adresse IP de la TV (ex. 192.168.1.20)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.startPairing() }) { Text("Appairer") }
            OutlinedButton(onClick = { vm.connectWifi() }) { Text("Connecter") }
        }
        if (wifiState == AndroidTvRemoteClient.State.WAITING_CODE) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = pairCode,
                    onValueChange = { pairCode = it.uppercase().take(6) },
                    label = { Text("Code TV (6 car.)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = { vm.submitPairingCode(pairCode) }) { Text("Valider") }
            }
        }
        if (wifiInfo.isNotBlank()) Text(wifiInfo, fontSize = 12.sp)
    }
}
