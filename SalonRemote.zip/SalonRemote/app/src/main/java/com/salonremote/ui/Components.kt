package com.salonremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salonremote.RemoteViewModel
import com.salonremote.ir.Device
import com.salonremote.ir.Keys

/** Bouton de base : retour haptique, appui/relâchement distincts (répétition IR tant que maintenu). */
@Composable
fun RemoteButton(
    onDown: () -> Unit,
    modifier: Modifier = Modifier,
    onUp: () -> Unit = {},
    shape: Shape = RoundedCornerShape(18.dp),
    container: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable BoxScope.() -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val down by rememberUpdatedState(onDown)
    val up by rememberUpdatedState(onUp)
    var pressed by remember { mutableStateOf(false) }
    val bg = if (pressed) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f) else container
    Box(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    down()
                    try {
                        tryAwaitRelease()
                    } finally {
                        pressed = false
                        up()
                    }
                })
            },
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Bouton lié à une touche d'un appareil. */
@Composable
fun Key(
    vm: RemoteViewModel,
    device: Device,
    key: String,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    container: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable BoxScope.() -> Unit
) {
    RemoteButton(
        onDown = { vm.pressDown(device, key) },
        onUp = { vm.pressUp(device, key) },
        modifier = modifier,
        shape = shape,
        container = container,
        content = content
    )
}

@Composable
fun KeyLabel(text: String, size: TextUnit = 14.sp, color: Color = Color.Unspecified) {
    Text(text, fontSize = size, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center, color = color)
}

@Composable
fun KeyIcon(icon: ImageVector, desc: String?, size: Int = 26) {
    Icon(icon, contentDescription = desc, modifier = Modifier.size(size.dp))
}

/** Rangée de touches de sélection directe (sources / entrées). */
@Composable
fun SourceRow(vm: RemoteViewModel, device: Device, items: List<Pair<String, String>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { (k, label) ->
            Key(vm, device, k, Modifier.weight(1f).height(46.dp)) { KeyLabel(label, 12.sp) }
        }
    }
}

/** Bascule verticale + / − avec titre au centre. */
@Composable
fun Rocker(
    vm: RemoteViewModel,
    device: Device,
    upKey: String,
    downKey: String,
    title: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .height(220.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Key(vm, device, upKey, Modifier.weight(1f).fillMaxWidth(), RoundedCornerShape(32.dp), Color.Transparent) {
            KeyIcon(Icons.Filled.Add, "$title +", 32)
        }
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Key(vm, device, downKey, Modifier.weight(1f).fillMaxWidth(), RoundedCornerShape(32.dp), Color.Transparent) {
            KeyIcon(Icons.Filled.Remove, "$title -", 32)
        }
    }
}

/** Ligne « − libellé + » pour les réglages fins (basses, aigus, trapèze, zoom). */
@Composable
fun Stepper(vm: RemoteViewModel, device: Device, minusKey: String, plusKey: String, label: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Key(vm, device, minusKey, Modifier.weight(1f).height(56.dp)) { KeyIcon(Icons.Filled.Remove, "$label -") }
        Box(Modifier.width(110.dp), contentAlignment = Alignment.Center) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        Key(vm, device, plusKey, Modifier.weight(1f).height(56.dp)) { KeyIcon(Icons.Filled.Add, "$label +") }
    }
}

/** Pavé directionnel circulaire entouré de 4 touches (haut-gauche, haut-droite, bas-gauche, bas-droite). */
@Composable
fun DPadBlock(vm: RemoteViewModel, device: Device, corners: List<Pair<String, String>>) {
    val pos = listOf(Alignment.TopStart, Alignment.TopEnd, Alignment.BottomStart, Alignment.BottomEnd)
    Box(Modifier.fillMaxWidth().height(290.dp), contentAlignment = Alignment.Center) {
        corners.forEachIndexed { i, (k, label) ->
            Key(vm, device, k, Modifier.align(pos[i]).size(width = 88.dp, height = 54.dp)) { KeyLabel(label, 13.sp) }
        }
        Box(
            Modifier
                .size(214.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Key(vm, device, Keys.UP, Modifier.align(Alignment.TopCenter).size(72.dp), CircleShape, Color.Transparent) {
                KeyIcon(Icons.Filled.KeyboardArrowUp, "Haut", 36)
            }
            Key(vm, device, Keys.DOWN, Modifier.align(Alignment.BottomCenter).size(72.dp), CircleShape, Color.Transparent) {
                KeyIcon(Icons.Filled.KeyboardArrowDown, "Bas", 36)
            }
            Key(vm, device, Keys.LEFT, Modifier.align(Alignment.CenterStart).size(72.dp), CircleShape, Color.Transparent) {
                KeyIcon(Icons.Filled.KeyboardArrowLeft, "Gauche", 36)
            }
            Key(vm, device, Keys.RIGHT, Modifier.align(Alignment.CenterEnd).size(72.dp), CircleShape, Color.Transparent) {
                KeyIcon(Icons.Filled.KeyboardArrowRight, "Droite", 36)
            }
            Key(
                vm, device, Keys.OK, Modifier.align(Alignment.Center).size(84.dp), CircleShape,
                MaterialTheme.colorScheme.secondaryContainer
            ) { KeyLabel("OK", 18.sp) }
        }
    }
}

@Composable
fun EmptyBox() = Box(Modifier.fillMaxSize())
