package com.salonremote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.salonremote.RemoteViewModel
import com.salonremote.ir.Device
import com.salonremote.ir.Keys

private val D = Device.PROJECTOR

@Composable
fun ProjectorScreen(vm: RemoteViewModel) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key(vm, D, Keys.POWER, Modifier.weight(1f).height(60.dp), container = Color(0xFFD32F2F)) {
                KeyIcon(Icons.Filled.PowerSettingsNew, "Power")
            }
            Key(vm, D, Keys.SOURCE, Modifier.weight(1f).height(60.dp)) { KeyLabel("Source") }
            Key(vm, D, Keys.MUTE, Modifier.weight(1f).height(60.dp)) { KeyIcon(Icons.Filled.VolumeOff, "Mute") }
        }
        SourceRow(
            vm, D,
            listOf(
                Keys.HDMI1 to "HDMI 1", Keys.HDMI2 to "HDMI 2", Keys.AV to "AV",
                Keys.USB to "USB", Keys.MIRROR to "Miroir"
            )
        )
        DPadBlock(
            vm, D,
            listOf(Keys.BACK to "Retour", Keys.MENU to "Menu", Keys.HOME to "Accueil", Keys.FLIP to "Flip")
        )
        Stepper(vm, D, Keys.VOL_DOWN, Keys.VOL_UP, "Volume")
        Stepper(vm, D, Keys.KEYSTONE_DOWN, Keys.KEYSTONE_UP, "Keystone")
        Stepper(vm, D, Keys.ZOOM_DOWN, Keys.ZOOM_UP, "Zoom")
    }
}
